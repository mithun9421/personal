package com.owner;

import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;

public class HostelDeletion {
	
	public static void deleteHostel(int id)
	{
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ROOM_FACILITIES WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			System.out.println("�re you sure you want to delete the hostel from the database(y/n)");
			char str = 0;
			try {
				str = br.readLine().charAt(0);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(str == 'y')
				pstmt.executeUpdate();
			else
				return;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
