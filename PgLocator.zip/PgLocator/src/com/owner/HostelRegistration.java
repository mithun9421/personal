package com.owner;

import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;
import com.hostel.HostelBean;

public class HostelRegistration {
	
	public static void registerHostel()
	{
		Connection conn = ConnectionManager.getConnection();
		BufferedReader br = new BufferedReader( new InputStreamReader (System.in));
		PreparedStatement ps = null;
		HostelBean hBean = new HostelBean();
	
		try
		{
		System.out.println("Enter the desired ID:");
		hBean.setHostelID(Integer.parseInt(br.readLine()));
		System.out.println("Enter the name of the hostel");
		hBean.setHostelName(br.readLine());
		System.out.println("Enter the address of the hostel");
		hBean.setHostelAddress(br.readLine());
		System.out.println("Enter the location");
		hBean.setHostelLocation(br.readLine());
		//System.out.println("Enter the rating");
		hBean.setHostelRating(Integer.parseInt("0"));
		//System.out.println("Enter the Feedback");
		hBean.setHostelFeedback("NA");
		System.out.println("Enter the room facilities:");
		System.out.println("Does the Accomdation has Wifi?");
		hBean.setRoomHasWifi(br.readLine().toUpperCase());
		System.out.println("Does the Accomdation has TV ?");
		hBean.setRoomHasTV(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation Provides Food ?");
		hBean.setRoomHasFood(br.readLine().toUpperCase());
		System.out.println("Is the Accomodation furnished ?");
		hBean.setRoomHasFurnished(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation has attached toilet ?");
		hBean.setRoomHasAttachedToilet(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation has single occupancy ?");
		hBean.setRoomHasSingleOccupancy(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation has shared occupancy ?");
		hBean.setRoomHasSharedOccupancy(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation contains the refrigerator");
		hBean.setRoomHasRefrigerator(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation has security ?");
		hBean.setRoomHasSecurity(br.readLine().toUpperCase());
		System.out.println("Does the Accomodation has washing machine ?");
		hBean.setRoomHasWashingMachine(br.readLine().toUpperCase());
		System.out.println("DOes the Accomodation has Cupboard ?");
		hBean.setRoomHasCupboard(br.readLine().toUpperCase());
		System.out.println("how many free cots are there in the accomodation ?");
		hBean.setRoomNoOfCotsVacant(Integer.parseInt(br.readLine()));
		System.out.println("What is the capacity of the accomodation");
		hBean.setRoomMaxCapacity(Integer.parseInt(br.readLine()));
		
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		String insertQuery = "insert into T_XBBNHGK_ACCOMODATION_DETAIL values(?,?,?,?,?,?)";
		try
		{
			ps = conn.prepareStatement(insertQuery);
			ps.setInt(1, hBean.getHostelID());
			ps.setString(2, hBean.getHostelName());
			ps.setString(3, hBean.getHostelAddress());
			ps.setString(4, hBean.getHostelLocation());
			ps.setInt(5, hBean.getHostelRating());
			ps.setString(6, hBean.getHostelFeedback());
			ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		hBean.setRoomHasVacant((hBean.getRoomMaxCapacity() - hBean.getRoomNoOfCotsVacant() == 0 ? "YES" : "NO" ));
		String insertQuery2 = "INSERT INTO T_XBBNHGK_ROOM_FACILITIES VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"; 
		try
		{
			ps = conn.prepareStatement(insertQuery2);
			ps.setInt(1, hBean.getHostelID());
			ps.setString(2, hBean.getRoomHasWifi());
			ps.setString(3, hBean.getRoomHasTV());
			ps.setString(4, hBean.getRoomHasFood());
			ps.setString(5, hBean.getRoomHasFurnished());
			ps.setString(6, hBean.getRoomHasAttachedToilet());
			ps.setString(7, hBean.getRoomHasSingleOccupancy());
			ps.setString(8, hBean.getRoomHasSharedOccupancy());
			ps.setString(9, hBean.getRoomHasRefrigerator());
			ps.setString(10, hBean.getRoomHasSecurity());
			ps.setString(11, hBean.getRoomHasWashingMachine());
			ps.setString(12, hBean.getRoomHasCupboard());
			ps.setString(13, hBean.getRoomHasVacant());
			ps.setInt(14, hBean.getRoomNoOfCotsVacant());
			ps.setInt(15, hBean.getRoomMaxCapacity());
			ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
