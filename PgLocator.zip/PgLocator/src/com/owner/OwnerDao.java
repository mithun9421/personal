package com.owner;

public class OwnerDao {

}
