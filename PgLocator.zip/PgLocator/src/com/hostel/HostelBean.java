package com.hostel;

public class HostelBean {
	
	private int hostelID;
	private String hostelName;
	private String hostelLocation;
	private int hostelRating;
	private String hostelFeedback;
	private String hostelAddress;
	private String roomHasWifi;
	private String roomHasTV;
	private String roomHasFood;
	private String roomHasCupboard;
	private String roomHasFurnished;
	private String roomHasAttachedToilet;
	private String roomHasSingleOccupancy;
	private String roomHasSharedOccupancy;
	private String roomHasRefrigerator;
	private String roomHasSecurity;
	private String roomHasWashingMachine;
	private String roomHasVacant;
	private int roomMaxCapacity;
	private int roomNoOfCotsVacant;
	
	
	public int getHostelID() {
		return hostelID;
	}
	public void setHostelID(int hostelID) {
		this.hostelID = hostelID;
	}
	public String getHostelName() {
		return hostelName;
	}
	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
	public String getHostelLocation() {
		return hostelLocation;
	}
	public void setHostelLocation(String hostelLocation) {
		this.hostelLocation = hostelLocation;
	}
	public int getHostelRating() {
		return hostelRating;
	}
	public void setHostelRating(int hostelRating) {
		this.hostelRating = hostelRating;
	}
	public String getHostelFeedback() {
		return hostelFeedback;
	}
	public void setHostelFeedback(String hostelFeedback) {
		this.hostelFeedback = hostelFeedback;
	}
	public String getHostelAddress() {
		return hostelAddress;
	}
	public void setHostelAddress(String hostelAddress) {
		this.hostelAddress = hostelAddress;
	}
	public String getRoomHasWifi() {
		return roomHasWifi;
	}
	public void setRoomHasWifi(String roomHasWifi) {
		this.roomHasWifi = roomHasWifi;
	}
	public String getRoomHasTV() {
		return roomHasTV;
	}
	public void setRoomHasTV(String roomHasTV) {
		this.roomHasTV = roomHasTV;
	}
	public String getRoomHasFood() {
		return roomHasFood;
	}
	public void setRoomHasFood(String roomHasFood) {
		this.roomHasFood = roomHasFood;
	}
	public String getRoomHasCupboard() {
		return roomHasCupboard;
	}
	public void setRoomHasCupboard(String roomHasCupboard) {
		this.roomHasCupboard = roomHasCupboard;
	}
	public String getRoomHasFurnished() {
		return roomHasFurnished;
	}
	public void setRoomHasFurnished(String roomHasFurnished) {
		this.roomHasFurnished = roomHasFurnished;
	}
	public String getRoomHasAttachedToilet() {
		return roomHasAttachedToilet;
	}
	public void setRoomHasAttachedToilet(String roomHasAttachedToilet) {
		this.roomHasAttachedToilet = roomHasAttachedToilet;
	}
	public String getRoomHasSingleOccupancy() {
		return roomHasSingleOccupancy;
	}
	public void setRoomHasSingleOccupancy(String roomHasSingleOccupancy) {
		this.roomHasSingleOccupancy = roomHasSingleOccupancy;
	}
	public String getRoomHasSharedOccupancy() {
		return roomHasSharedOccupancy;
	}
	public void setRoomHasSharedOccupancy(String roomHasSharedOccupancy) {
		this.roomHasSharedOccupancy = roomHasSharedOccupancy;
	}
	public String getRoomHasRefrigerator() {
		return roomHasRefrigerator;
	}
	public void setRoomHasRefrigerator(String roomHasRefrigerator) {
		this.roomHasRefrigerator = roomHasRefrigerator;
	}
	public String getRoomHasSecurity() {
		return roomHasSecurity;
	}
	public void setRoomHasSecurity(String roomHasSecurity) {
		this.roomHasSecurity = roomHasSecurity;
	}
	public String getRoomHasWashingMachine() {
		return roomHasWashingMachine;
	}
	public void setRoomHasWashingMachine(String roomHasWashingMachine) {
		this.roomHasWashingMachine = roomHasWashingMachine;
	}
	public int getRoomMaxCapacity() {
		return roomMaxCapacity;
	}
	public void setRoomMaxCapacity(int roomMaxCapacity) {
		this.roomMaxCapacity = roomMaxCapacity;
	}
	
	public String getRoomHasVacant() {
		return roomHasVacant;
	}
	public void setRoomHasVacant(String roomHasVacant) {
		this.roomHasVacant = roomHasVacant;
	}
	public int getRoomNoOfCotsVacant() {
		return roomNoOfCotsVacant;
	}
	public void setRoomNoOfCotsVacant(int roomNoOfCotsVacant) {
		this.roomNoOfCotsVacant = roomNoOfCotsVacant;
	}
	
	
	

}
