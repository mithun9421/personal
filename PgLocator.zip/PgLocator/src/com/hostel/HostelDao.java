package com.hostel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

public class HostelDao {
	@SuppressWarnings("rawtypes")
	List getHostels;
		@SuppressWarnings({ "rawtypes" })
		public void getHostels() throws Exception, IOException{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			HostelBean hBean = new HostelBean();
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			int choice = 0;
			//String searchQuery = "SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES where ";
			System.out.println("1) Display all the hostels\n2) Display the facilities");
			choice = Integer.parseInt(br.readLine());
			
			switch(choice)
			{
			case 1: List<HostelBean> hostelList = GetHostel.getAllHostels();
					Iterator<HostelBean> iter = hostelList.iterator();
					System.out.println(String.format("%-20s%-20s%-25s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s","Hostel ID","Hostel Name","Hostel Address","Hostel Locality","Hostel Rating","Hostel Feedback","Wifi","TV","Food","Pre-fursnished","Attached Toilet","Single Occupancy","Shared Occupancy","Refrigerator","Security","Washing machine","Cupboard","Has Room Vacant","Free Cots Available"));
					while(iter.hasNext())
					{
						HostelBean hb = iter.next();
						System.out.println(String.format("%-20s%-20s%-25s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s",hb.getHostelID(),hb.getHostelName(),hb.getHostelAddress(),hb.getHostelLocation(),hb.getHostelRating(),hb.getHostelFeedback(),hb.getRoomHasWifi(),hb.getRoomHasTV(),hb.getRoomHasFood(),hb.getRoomHasFurnished(),hb.getRoomHasAttachedToilet(),hb.getRoomHasSingleOccupancy(),hb.getRoomHasSharedOccupancy(),hb.getRoomHasRefrigerator(),hb.getRoomHasSecurity(),hb.getRoomHasWashingMachine(),hb.getRoomHasCupboard(),hb.getRoomHasVacant(),hb.getRoomMaxCapacity()));
					}
					break;
					
			
			case 2: List<HostelBean> spechostelList = GetHostel.getSpecHostels();
					Iterator<HostelBean> iterspec = spechostelList.iterator();
					System.out.println(String.format("%-20s%-20s%-25s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s","Hostel ID","Hostel Name","Hostel Address","Hostel Locality","Hostel Rating","Hostel Feedback","Wifi","TV","Food","Pre-fursnished","Attached Toilet","Single Occupancy","Shared Occupancy","Refrigerator","Security","Washing machine","Cupboard","Has Room Vacant","Free Cots Available"));
					while(iterspec.hasNext())
					{
						HostelBean hb = iterspec.next();
						System.out.println(String.format("%-20s%-20s%-25s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s%-20s",hb.getHostelID(),hb.getHostelName(),hb.getHostelAddress(),hb.getHostelLocation(),hb.getHostelRating(),hb.getHostelFeedback(),hb.getRoomHasWifi(),hb.getRoomHasTV(),hb.getRoomHasFood(),hb.getRoomHasFurnished(),hb.getRoomHasAttachedToilet(),hb.getRoomHasSingleOccupancy(),hb.getRoomHasSharedOccupancy(),hb.getRoomHasRefrigerator(),hb.getRoomHasSecurity(),hb.getRoomHasWashingMachine(),hb.getRoomHasCupboard(),hb.getRoomHasVacant(),hb.getRoomMaxCapacity()));
					}
					break;
			
			default: System.out.println("Try again");
			}
			
			
		
				try {
				
					if(pstmt != null)					
						pstmt.close();				
					if(conn != null)
						conn.close();
			}			
			 catch (SQLException e) {
					e.printStackTrace();
				}
		}

	}

