package com.tenant;

import java.io.*;
public class TenantDetailsGather {
	
	public void gatherDetails()
	{
		int tempuser_ID;
		String tempuser_name;
		int tempuser_phone_no;
		String tempuser_marital_status;
		
		@SuppressWarnings("unused")
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
		try {
			tempuser_ID = Integer.parseInt(br.readLine());
			tempuser_name = br.readLine();
			tempuser_phone_no = Integer.parseInt(br.readLine());
			tempuser_marital_status = br.readLine();
		} catch (NumberFormatException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
