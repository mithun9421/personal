package com.tenant;

public class TenantDao {
	
	
	public void tenantRegister()
	{
		
	}
	
}