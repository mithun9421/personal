package com.app;

import java.io.*;
import java.util.*;

import com.contractor.ContractorDao;
import com.contractor.UpdateHostelFeedback;
import com.hostel.HostelBean;
import com.hostel.HostelDao;
import com.owner.HostelDeletion;
import com.owner.HostelRegistration;


public class ApplicationStart {

	public static void main(String[] args) throws IOException, Exception 
	{
			//Hello Run me through
			Scanner scn = new Scanner(System.in);
			char contornot ;
			do
			{
			System.out.println("Please select an option to continue:" + "\n" 
			+"1.Get list of hostels" + "\n" 
			+ "2.Contractor Feedback" + "\n" 
			+ "3.Register for new hostel" +"\n" 
			+ "4.Remove existing hostel" + "\n" 
			+ "5.Get the balance of the tenants" + "\n" 
			+ "6.Book for hostel" + "\n");
			int choice = scn.nextInt();
			
			switch (choice) {
			case 1:	HostelDao hostelDao = new HostelDao();
				    hostelDao.getHostels();
				    break;
			
			case 2: String uname = scn.next().toLowerCase();
					String pwd = scn.next().toLowerCase();
					boolean isValid = ContractorDao.isValid(uname,pwd);
					if(isValid == true)
							UpdateHostelFeedback.updateFeedback();
					else
					{
						System.out.println("Wrong Password...try again");
					}
					break;
					
			case 3: HostelRegistration.registerHostel();
					break;
					
			case 4: System.out.println("Enter the Hostel ID for deletion");
					int delID = scn.nextInt();
					HostelDeletion.deleteHostel(delID);
					break;
					
			default: System.out.println("Please enter a valid choice to continue(yes/no)");
			}
			
			System.out.println("Do you wish to continue:");
			contornot = Character.toLowerCase(scn.next().charAt(0));
			}while(contornot == 'y');

		}
}
