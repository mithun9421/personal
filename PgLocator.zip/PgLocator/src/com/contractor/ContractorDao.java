package com.contractor;

import java.sql.*;

import com.hostel.ConnectionManager;

public class ContractorDao {

	public static boolean isValid(String username,String password) throws SQLException
	{
		
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
			stmt = con.prepareStatement("select * from T_XBBNHGK_CONTRACTOR_CREDITS where cid = ? AND cpwd = ?");
			stmt.setString(1, username);
			stmt.setString(2, password);
		
		boolean isValid = false;
		ResultSet rs = null;
		
		rs = stmt.executeQuery();
			
		while(rs.next())
		{
			isValid = true;
		}
		return isValid;
		
	}
	
}
